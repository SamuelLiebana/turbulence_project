function tst7

spmd
    o = gop(@plus,labindex);
end
o{end}
